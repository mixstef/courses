
class RuntimeStack:

	def __init__(self,initial_symbols=None):
	
		""" Initializes the runtime stack and pushes "main" frame.
		`initial_symbols`, if not None, contain symbols that will
		be predefined in "main" frame. `initial_symbols` must be a
		data struct suitable for a new python dict initialization. """ 
	
		if initial_symbols is not None:
			d = dict(initial_symbols)
		else:
			d = {}
		self.stack = [{'retval':None, 'symbols':d}]
		
		
	def push_frame(self,initial_symbols=None):
	
		""" Pushes a new frame into runtime stack, populated by
		`initial_symbols`, if not None. `initial_symbols` must be a
		data struct suitable for a new python dict initialization. """
		
		if initial_symbols is not None:
			d = dict(initial_symbols)
		else:
			d = {}
		self.stack.append({'retval':None, 'symbols':d})
		
		
	def pop_frame(self):
	
		""" Discards the frame at the top of the runtime stack """
		
		self.stack.pop()
		
		
	def dereference(self,varname):
	
		""" Returns value of `varname` symbol if present in current frame.
		Returns None otherwise. """
		
		current_symbols = self.stack[-1]['symbols']
		if varname in current_symbols:
			return current_symbols[varname]
			
		return None	# symbol not found
		
		
	def assign(self,varname, value):
	
		""" Sets `varname` symbol in current frame to `value` """
		
		self.stack[-1]['symbols'][varname] = value
		
		
	@property
	def return_value(self):
	
		""" Returns the value of return_value in current frame """
		
		return self.stack[-1]['retval']
		
		
	@return_value.setter
	def return_value(self,value):
	
		""" Sets the value of return_value in current frame to `value` """
		
		self.stack[-1]['retval'] = value
		
		
