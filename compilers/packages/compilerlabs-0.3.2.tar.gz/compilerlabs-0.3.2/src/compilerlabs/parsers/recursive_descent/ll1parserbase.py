from abc import ABC,abstractmethod

from .. import ParseError


class TokenMatchError(ParseError):

    """ A subclass of ParseError for raising when tokens mismatch
    in the 'match' phase of the LL1 parser"""
    
    def __init__(self,next_symbol,expected):
    
        self.next_symbol = next_symbol
        self.expected = expected
        self.message = f'Expected {self.expected}, found {self.next_symbol.token} instead'
        super().__init__(self.next_symbol,self.message)



class LL1ParserBase(ABC):

    """ A class to be used for creating LL1 parsers via the recursive descent method"""


    def __init__(self,scanner):
            
        self.scanner = scanner
        
        # get initial input symbol
        self.next_symbol = next(self.scanner)


    def match(self,expected):
    
        if self.next_symbol.token == expected:
            # proceed to next token, if not at end-of-text
            if self.next_symbol.token is not None:
                self.next_symbol = next(self.scanner)

        else:
            raise TokenMatchError(self.next_symbol,expected)


    def error(self,message,symbol=None):
    
        if symbol is None: symbol = self.next_symbol        
        raise ParseError(symbol,message)
                
    
    @abstractmethod        
    def parse(self):
        pass
        
