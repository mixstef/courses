#include <stdio.h>
#include <stdlib.h>

#define INUM 3

int main() {
FILE *fp;

int mat[] = {125,34,-7};

  fp = fopen("test.bin","wb");

  fwrite(mat,sizeof(int),INUM,fp);


  fclose(fp);

  return 0;
}

/* Hex dump:

$ hd test.bin
00000000  7d 00 00 00 22 00 00 00  f9 ff ff ff              |}...".......|
0000000c

*/

