from .simpledfa import DFA

