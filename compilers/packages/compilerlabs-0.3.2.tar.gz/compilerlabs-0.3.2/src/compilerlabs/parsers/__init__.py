class ParseError(Exception):
    
    """ A generic parsing error class, with default reporting of position of faulting symbol """
    
    def __init__(self,symbol,message):
    
        self.symbol = symbol
        self.message = message
        super().__init__(f"Syntax error at line {self.symbol.lineno} char {self.symbol.charpos}: {self.message}")
        
            

from .recursive_descent.ll1parserbase import LL1ParserBase,TokenMatchError
