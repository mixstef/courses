from simpledfa import DFA

