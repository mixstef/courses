from setuptools import setup

setup(
    name='Plex',
    version='2.0.1',
    packages=['plex'],
)

