import re
from collections import namedtuple
from operator import countOf
from enum import Enum

Symbol = namedtuple('Symbol','token, lexeme, lineno, charpos')

TokenAction = Enum('TokenAction','IGNORE TEXT ERROR')


class TokenizerError(Exception):
	
	def __init__(self,lexeme,lineno,charpos):
	
		self.lexeme = lexeme
		self.lineno = lineno
		self.charpos = charpos
		self.message = f"Invalid input '{lexeme}' at line {lineno} char {charpos}"
		super().__init__(self.message)
		


class Tokenizer:

	""" A tokenizer using python regular expressions, based on module
	re tokenizer example."""
	
	def __init__(self):
					
		self.pname = 0
		self.patterns = []
		self.keywords = {}
		self.actions = {}
		
		
	def pattern(self,regpat,token,keywords=None):
	
		""" Adds a regex pattern specified by `regpat` to the tokenizer,
		order of pattern addition determines precedence. When detected,
		`token` is returned together with corresponding text.
		An optional dictionary or sequence `keywords` can be supplied
		specifying strings to be specially handled as protected words 	
		(dict values define the tokens to be returned on this special 
		cases, in case of sequence the lexeme found is returned as token
		"""
		
		groupname = f'G{self.pname}'
		self.pname += 1
		
		self.patterns.append(f'(?P<{groupname}>{regpat})')
		
		self.actions[groupname] = token
		
		self.keywords[groupname] = {}
		if keywords is not None:
			if isinstance(keywords,dict):
				self.keywords[groupname] = dict(keywords)
			else:	# should be a sequence
				self.keywords[groupname] = {item:item for item in keywords}
			
			
	def scan(self,text,flags=0,eot=True):
	
		""" Tokenizes iteratively input `text`. Yields on each call
		a Symbol(token,lexeme,lineno,charpos) namedtuple. 
		`flags`, as defined in re module, can optionally be specified.
		If `eot` is True, a symbol with token None is emitted
		at the end."""
		
		tok_rexp = re.compile('|'.join(self.patterns),flags)

		linestart = 0	# pos in text that current line starts
		lineno = 1	# number of current line
		
		for m in tok_rexp.finditer(text):
			group_name = m.lastgroup
			token = self.actions[group_name]
			lexeme = m.group()
			charpos = m.start() - linestart
			tokline = lineno
			
			# check if newlines present
			if (i := lexeme.rfind('\n'))>=0:	# at least one newline in match
				# adjust line start
				linestart = m.start() + i + 1
				
				# incr lineno by total number of newlines in match
				lineno += countOf(lexeme,'\n')
			
			if token==TokenAction.IGNORE: continue	# skip this
			
			if token==TokenAction.ERROR:
				raise TokenizerError(lexeme,tokline,charpos) 
				
			if token==TokenAction.TEXT:
				token = lexeme
			
			if lexeme in self.keywords[group_name]:
				token = self.keywords[group_name][lexeme]
				
			yield Symbol(token,lexeme,tokline,charpos)
			
			
		# no more input, emit EOT if requested
		if eot:
			charpos = len(text) - linestart
			yield Symbol(None,'',lineno,charpos)
			
