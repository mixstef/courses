#include <stdio.h>
#include <stdlib.h>

#define INUM 3

int main() {
FILE *fp;
int i;

int mat[] = {125,34,-7};

  fp = fopen("test.txt","w");

  for (i=0;i<INUM;i++) {
    fprintf(fp,"%d\n",mat[i]);
  }

  fclose(fp);

  return 0;
}

/* Hex dump:

$ hd test.txt
00000000  31 32 35 0a 33 34 0a 2d  37 0a                    |125.34.-7.|
0000000a

*/
